#include <stdio.h>
#include <stdlib.h>
#include "pila.h"

#define ARCHIVO "registroCuentaBancaria.dat"
#define SALDOS "saldos.dat"

typedef struct
{
    int idRegistro;
    int nroCuenta;
    char nombreCliente[30];
    char apellidoCliente[30];
    char fechaMovimiento[11];  // ejemplo �2021-02-15�
    float importe;
} stRegistroCuentaBancaria;

typedef struct
{
    int nroCuenta;
    char nombreCliente[30];
    char apellidoCliente[30];
    float saldo;
} stSaldos;


int pasarRegistros(stRegistroCuentaBancaria registros[], int dim); // 1
void mostrarArreglo(stRegistroCuentaBancaria registros[], int validos); // 2
void mostrarElemento(stRegistroCuentaBancaria registro); // 2
void ordenarPorNroCuenta(stRegistroCuentaBancaria registros[], int validos); // 3
int buscarMenor(stRegistroCuentaBancaria registros[], int validos, int inicio); // 3
int contarRegistros(char rutaArchivo[]); // 4
void mostrarRegistro(int nroReg); // 9
void mostrarArchivo(char rutaArchivo[]); // 9

int main() // 11
{
    stRegistroCuentaBancaria registros[100];
    int salir=0, opcion, validos=0, largo=0, registro=0;
    do
    {
        system("cls");
        printf("1. Pasar registros\n");
        printf("2. Mostrar arreglo de registros\n");
        printf("3. Ordenar por nro de cuenta\n");
        printf("4. Contar registros\n");
        printf("5. Mostrar registro\n");
        printf("6. Mostrar archivos\n");
        printf("0. SALIR\n");
        printf("Seleccione una opcion: ");
        scanf("%d", &opcion);
        switch(opcion)
        {
        case 1:
            system("cls");
            validos = pasarRegistros(registros, 100);
            system("pause");
            break;
        case 2:
            system("cls");
            mostrarArreglo(registros, validos);
            system("pause");
            break;
        case 3:
            system("cls");
            ordenarPorNroCuenta(registros, validos);
            mostrarArreglo(registros,validos);
            system("pause");
            break;
        case 4:
            system("cls");
            largo= contarRegistros(ARCHIVO);
            printf("Hay cargadas %d registros", largo);
            system("pause");
            break;
        case 5:
            system("cls");
            printf("Ingrese un registro: ");
            scanf("%d", &registro);
            system("cls");
            puts("Mostrando registro..");
            mostrarRegistro(registro);
            system("pause");
            break;
        case 6:
            system("cls");
            mostrarArchivo(SALDOS);
            system("pause");
            break;
        case 0:
            system("cls");
            salir=1;
            system("pause");
            break;
        default:
            system("cls");
            puts("Opcion incorrecta");
            system("pause");
            break;
        }

    }
    while(!salir);

    return 0;
}

int pasarRegistros(stRegistroCuentaBancaria registros[], int dim)
{
    FILE * archivo=fopen(ARCHIVO, "rb");
    stRegistroCuentaBancaria registroAux;
    int i=0;
    if(archivo)
    {
        while(fread(&registroAux, sizeof(stRegistroCuentaBancaria), 1, archivo)>0 && i<dim)
        {
            registros[i]=registroAux;
            i++;
        }
    }
    fclose(archivo);
    return i;

}

void mostrarArreglo(stRegistroCuentaBancaria registros[], int validos)
{
    int i=0;
    while(i<validos)
    {
        mostrarElemento(registros[i]);
        i++;
    }
}

void mostrarElemento(stRegistroCuentaBancaria registro)
{
    printf("--------------------------------");
    printf("ID: %d\n", registro.idRegistro);
    printf("NRO CUENTA: %d\n", registro.nroCuenta);
    printf("NOMBRE: %s\n", registro.nombreCliente);
    printf("APELLIDO: %s\n", registro.apellidoCliente);
    printf("FECHA: %s\n", registro.fechaMovimiento);
    printf("IMPORTE: %.2f\n", registro.importe);
    printf("--------------------------------");
}

void ordenarPorNroCuenta(stRegistroCuentaBancaria registros[], int validos)
{
    int i=0;
    int posMen;
    stRegistroCuentaBancaria aux;
    while(i<validos)
    {
        posMen=buscarMenor(registros, validos, i);
        aux=registros[posMen];
        registros[posMen]=registros[i];
        registros[i]=aux;
        i++;
    }
}

int buscarMenor(stRegistroCuentaBancaria registros[], int validos, int inicio)
{
    int posMen=inicio;
    int menor=registros[posMen].nroCuenta;
    while(inicio<validos)
    {
        if(menor>registros[inicio+1].nroCuenta)
        {
            menor=registros[inicio+1].nroCuenta;
            posMen=inicio+1;
        }
        inicio++;
    }
    return posMen;
}

int contarRegistros(char rutaArchivo[])
{
    FILE * archivo=fopen(rutaArchivo, "rb");
    fseek(archivo, 0, SEEK_END);
    int i=ftell(archivo)/sizeof(stRegistroCuentaBancaria);
    return i;
}

void mostrarRegistro(int nroReg)
{
    int registros= 0;
    registros=contarRegistros(ARCHIVO);
    stRegistroCuentaBancaria aux;
    if(registros>0 && nroReg<=registros)
    {
        FILE * archivo=fopen(ARCHIVO, "rb");
        nroReg=nroReg-1;
        if(archivo)
        {
            fseek(archivo, sizeof(stRegistroCuentaBancaria)*nroReg, SEEK_SET);
            fread(&aux, sizeof(stRegistroCuentaBancaria), 1, archivo);
        }
        else
        {
            puts("Error de archivo o el registro ingresado excede el archivo");
        }
        fclose(archivo);
        mostrarElemento(aux);
    }
}

void mostrarArchivo(char rutaArchivo[])
{
    FILE * archivo=fopen(rutaArchivo, "rb");
    stRegistroCuentaBancaria aux;
    while(fread(&aux, sizeof(stRegistroCuentaBancaria), 1, archivo)>0)
    {
        mostrarElemento(aux);
    }
}


