#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include "pila.h"

void placaVideoUsr(int mSeguro, int cantReps, Pila * p); // 1
void placaVideoRandom(int mSeguro, int cantReps, Pila * p); // 1
int ordenarValoresCoins(Pila origen, int a[], Pila * destino); // 2a y 2b
void mostrarArreglo(int a[], int validos); // 2b
int buscarMaximoArreglo(int a[], int validos); // 3a

int main()
{
    int cantRepeticiones, modoSeguro, usrOrRandom, validos = 0, mayorArreglo = 0;
    int arregloB[100];

    Pila coinsPorDia, pilaA;
    inicpila(&coinsPorDia);
    inicpila(&pilaA);

    printf("Cuantas veces desea minar ");
    scanf("%d", &cantRepeticiones);

    printf("\nDesea ingresar los valores por consola (0) o generarlos de manera aleatoria (1) ");
    scanf("%d", &usrOrRandom);

    printf("\nDesea utilizar el modo seguro 1 = on / 0 = off ");
    scanf("%d", &modoSeguro);

    system("cls");

    if(usrOrRandom == 0)
    {
        placaVideoUsr(modoSeguro, cantRepeticiones, &coinsPorDia);
    }
    else
    {
        placaVideoRandom(modoSeguro, cantRepeticiones, &coinsPorDia);
    }

    printf("Coins generadas por ciclo en un dia");
    mostrar(&coinsPorDia);

    validos = ordenarValoresCoins(coinsPorDia, arregloB, &pilaA);

    printf("\n\nArreglo luego de ordenar\n\n");
    mostrarArreglo(arregloB, validos);
    mayorArreglo = buscarMaximoArreglo(arregloB, validos);

    printf("\n\nEl valor maximo es %d", mayorArreglo);

    printf("\n\nPila luego de ordenar");
    mostrar(&pilaA);

    return 0;
}

void placaVideoUsr(int mSeguro, int cantReps, Pila * p)
{
    int i = 0, valorCoin;

    for(i = 0; i<cantReps; i++)
    {
        if(mSeguro == 1)
        {
            printf("Ingrese el valor de sus coins (entre 10 y 40) ");
            scanf("%d", &valorCoin);

            apilar(p, valorCoin);
        }
        else
        {
            printf("Ingrese el valor de sus coins (entre -20 y 100) ");
            scanf("%d", &valorCoin);

            apilar(p, valorCoin);
        }
    }
}

void placaVideoRandom(int mSeguro, int cantReps, Pila * p)
{
    srand(time(NULL));

    int i = 0;

    for(i=0; i<cantReps; i++)
    {
        if(mSeguro == 1)
        {
            apilar(p, rand()%31 + 10);
        }
        else
        {
            apilar(p, rand()%121 - 20);
        }
    }
}

int ordenarValoresCoins(Pila origen, int a[], Pila * destino)
{
    int i = 0;

    Pila aux;
    inicpila(&aux);

    while(!pilavacia(&origen))
    {
        apilar(&aux, desapilar(&origen));

        if(tope(&aux) < 40 && tope(&aux) > -20)
        {
            apilar(destino, desapilar(&aux));
        }
        else
        {
            a[i] = tope(&aux);
            i++;
        }
    }

    return i;
}

void mostrarArreglo(int a[], int validos)
{
    int i = 0;

    for(i=0; i<validos; i++)
    {
        printf("| %d ", a[i]);
    }
}

int buscarMaximoArreglo(int a[], int validos)
{
    int i = 0, mayor = 0;

    mayor = a[i];

    for (i=1; i<validos; i++)
    {
        if(a[i]>mayor)
        {
            mayor = a[i];
        }
    }

    return mayor;
}
