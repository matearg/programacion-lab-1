#ifndef LEERTECLADO_H_INCLUDED
#define LEERTECLADO_H_INCLUDED

#define TEXTO_MAX 100

char leerCaracter(char textoIngresar[TEXTO_MAX]);
char * leerString(char textoIngresar[TEXTO_MAX], int tamanio);

#endif // LEERTECLADO_H_INCLUDED
