#ifndef MENSAJES_H_INCLUDED
#define MENSAJES_H_INCLUDED

void printfError(char mensaje[]);
void printfWarning(char mensaje[]);
void printfSucces(char mensaje[]);

void barraTitulos();
void tituloPrincipal();
void tituloSecciones(char * titulo);

#endif // MENSAJES_H_INCLUDED
